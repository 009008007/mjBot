# MJAI + ONNX Runtime: phase 1

A compact, offline-at-run-time Rust demonstration of MJAI JSON input, fixed-size state, stack-resident features, a borrowed tensor, and an MJAI JSON response. The toy input and output contracts below are explicit placeholders, **not** a Mortal-compatible encoder or policy.

## Requirements

- Rust and Cargo 1.81 or later.
- The first Cargo build needs the pinned `ort` crate and other dependencies available from Cargo's cache or a configured registry. Afterwards, use `cargo run --offline ...` and `cargo test --offline` if everything is cached.
- Mock inference does **not** need an ONNX Runtime shared library or an ONNX model.
- Real inference uses `ort` 2.0.0-rc.10 and a compatible ONNX Runtime 1.22 shared library, installed separately. `ORT_DYLIB_PATH` should point to the actual `.so`, `.dylib`, or `.dll` file. The library architecture must match the executable. No model or native runtime is included.

## Run the mock

From this folder:

```sh
cargo run --release
cargo test
```

With no input, the program uses a single built-in sample event. The response on stdout is:

```json
{"type":"dahai","actor":0,"pai":"1m","tsumogiri":true}
```

For the included starting hand and draw (bash/zsh):

```sh
cargo run --release -- --seat 0 < examples/draw.jsonl
```

Or in PowerShell:

```powershell
Get-Content examples/draw.jsonl | cargo run --release -- --seat 0
```

Expected stdout for that fixture:

```json
{"type":"dahai","actor":0,"pai":"E","tsumogiri":true}
```

Memory layout information and diagnostics go to stderr. The program reads newline-delimited events to EOF, then makes at most one decision. If an own draw is not awaiting a discard, it outputs `{"type":"none"}`. An input `none` preserves an existing pending decision. This is a batch demonstration, not a continuous request/response MJAI process.

## Use a model matching the demo contract

On macOS/Linux (adjust the shared-library extension and paths):

```sh
export ORT_DYLIB_PATH=/absolute/path/to/libonnxruntime.dylib
cargo run --release -- --model /path/to/demo_model.onnx < examples/draw.jsonl
```

On Windows PowerShell:

```powershell
$env:ORT_DYLIB_PATH = 'C:\path\to\onnxruntime.dll'
Get-Content examples/draw.jsonl | cargo run --release -- --model 'C:\path\to\demo_model.onnx'
```

A positional model path also works. The chosen runtime library must match the version and architecture required by `ort`. `GraphOptimizationLevel::Level3` is configured explicitly. The code builds a session for its single inference; a benchmark or long-running process should build it once and reuse it, then measure initialization, feature extraction, and inference separately.

## Demonstration contract and limitations

- Input: exactly one `f32` tensor of shape `[1, 4, 34, 9]` in row-major order. The 1 is the batch axis; the in-memory Rust array is `[4][34][9]`. This shape is a **TODO**.
- Output: exactly one `f32` tensor of shape `[1, 34]`. Each value is treated as the score for one tile category. This mapping is a **TODO**. The model must use the exact feature semantics in `extract_features`, not merely the same shape.
- Channel 0 stores cumulative own-tile counts; channel 1 stores red-five counts; channel 2 marks the last draw; channel 3 stores cumulative visible discards. Unused entries in the 9-wide axis are zero.
- Supported input events are `start_game`, `start_kyoku`, `tsumo`, `dahai`, `end_kyoku`, `end_game` and `none`. A `start_game.id`, when present, selects the player's seat and overrides `--seat`; otherwise the CLI seat or default 0 is used. A `dahai` must include the boolean `tsumogiri`. Other events, including calls/melds, fail rather than silently corrupting the state. Opponent hidden draws may be `"?"`; the user's own hand and draws must be visible. This simplified ruleset assumes at most one red five in each suit.
- The mock only ranks a toy count-derived score. Real-model scores are filtered against tile categories in the hand; this is not a complete rules/legal-action mask. It neither handles calls, wins, riichi restrictions, nor validates a complete match. A proposal does not mutate the state until the corresponding `dahai` event is received.
- `flat_view` borrows the array without allocating or copying elements. In mock mode, pointer equality verifies this Rust-side view only. In real mode `TensorRef::from_array_view` wraps the same borrowed CPU buffer; ONNX Runtime may still allocate/copy internally or for another device. This is not a proof of end-to-end zero-copy inference.
- Fixed arrays avoid per-element heap allocations in state and features; event parsing, ONNX Runtime, and output handling may allocate. Stack allocation and contiguity alone do not guarantee a speedup: benchmark the relevant workload.

## Adapting to Mortal or another actual model

Obtain the model's actual input names, element types, shapes, feature semantics, action vocabulary, and legal-action mask. Implement the full supported MJAI state transitions, change the compile-time shapes and encoder, pass every required input, and decode and validate the model's real actions. Do not infer compatibility from matching dimensions.

## Validation status

The code and its unit tests were prepared and checked against the `ort` rc.10 API documentation. They could not be compiled or run in the authoring environment because a Rust toolchain and ONNX Runtime were unavailable there. Run `cargo test` and the mock commands above on a Rust-equipped machine; real inference additionally needs a model that conforms to the demo contract.
