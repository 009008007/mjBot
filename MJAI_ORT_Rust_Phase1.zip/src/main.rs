use std::{env, error::Error, io::{self, BufRead, IsTerminal}, path::Path};

use ort::{
    session::{builder::GraphOptimizationLevel, Session},
    value::TensorRef,
};
use serde::{Deserialize, Serialize};

const TILE_TYPES: usize = 34;
const CHANNELS: usize = 4;
const WIDTH: usize = 9;
const ELEMENTS: usize = CHANNELS * TILE_TYPES * WIDTH;
// TODO: Replace with actual model dimensions and implement its real feature encoding.
const INPUT_SHAPE: [usize; 4] = [1, CHANNELS, TILE_TYPES, WIDTH];
// TODO: Replace with the actual model's output shape and action mapping.
const OUTPUT_SHAPE: [i64; 2] = [1, TILE_TYPES as i64];

// Nested arrays are inline, not pointer-linked rows: this is one contiguous
// 4,896-byte f32 buffer. This avoids the per-element boxed objects and separate
// row allocations of a typical Python list-of-lists. Other runtimes can also
// provide contiguous buffers, so performance still needs measurement.
// On this target the buffer is small enough for a typical stack;
// much larger model-specific tensors might need a different storage strategy.
type FeatureTensor = [[[f32; WIDTH]; TILE_TYPES]; CHANNELS];

type AppResult<T> = Result<T, Box<dyn Error>>;

const TILE_NAMES: [&str; TILE_TYPES] = [
    "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m",
    "1p", "2p", "3p", "4p", "5p", "6p", "7p", "8p", "9p",
    "1s", "2s", "3s", "4s", "5s", "6s", "7s", "8s", "9s",
    "E", "S", "W", "N", "P", "F", "C",
];

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Tile {
    index: usize,
    red: bool,
}

fn parse_tile(pai: &str) -> AppResult<Tile> {
    let honor = match pai {
        "E" => Some(27), "S" => Some(28), "W" => Some(29), "N" => Some(30),
        "P" => Some(31), "F" => Some(32), "C" => Some(33),
        _ => None,
    };
    if let Some(index) = honor {
        return Ok(Tile { index, red: false });
    }
    let bytes = pai.as_bytes();
    if !(bytes.len() == 2 || bytes.len() == 3) || !(b'1'..=b'9').contains(&bytes[0]) {
        return Err(format!("invalid known tile: {pai:?}").into());
    }
    let suit = match bytes[1] {
        b'm' => 0, b'p' => 1, b's' => 2,
        _ => return Err(format!("invalid tile suit: {pai:?}").into()),
    };
    let red = bytes.len() == 3;
    if red && (bytes[2] != b'r' || bytes[0] != b'5') {
        return Err(format!("invalid red five: {pai:?}").into());
    }
    Ok(Tile { index: suit * 9 + usize::from(bytes[0] - b'1'), red })
}

fn red_suit(index: usize) -> Option<usize> {
    if index < 27 && index % 9 == 4 { Some(index / 9) } else { None }
}

fn tile_name(tile: Tile) -> &'static str {
    if tile.red {
        match tile.index {
            4 => "5mr", 13 => "5pr", 22 => "5sr",
            _ => unreachable!("only a five can be red"),
        }
    } else {
        TILE_NAMES[tile.index]
    }
}

// This deliberately covers only a small, explicit subset of MJAI. Unknown
// events (including calls/melds) fail deserialization instead of being ignored.
// Extra fields on supported events are accepted, as in real MJAI records.
#[derive(Debug, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
enum Event {
    StartGame { id: Option<u8> },
    StartKyoku { tehais: [[String; 13]; 4] },
    Tsumo { actor: u8, pai: String },
    Dahai { actor: u8, pai: String, tsumogiri: bool },
    EndKyoku {},
    EndGame {},
    None {},
}

// The persistent state uses only fixed-size arrays and scalars. The JSON parser
// does allocate Strings temporarily; that is separate from the fixed-size state
// and feature buffer. No Vec or HashMap is required for those two structures.
#[derive(Debug)]
struct GameState {
    seat: u8,
    hand: [u8; TILE_TYPES],
    red_fives: [u8; 3],
    red_discards: [u8; 3],
    discards: [u8; TILE_TYPES],
    last_draw: Option<Tile>,
    can_discard: bool,
}

impl GameState {
    fn new(seat: u8) -> AppResult<Self> {
        if seat > 3 { return Err("seat must be in 0..=3".into()); }
        Ok(Self {
            seat,
            hand: [0; TILE_TYPES],
            red_fives: [0; 3],
            red_discards: [0; 3],
            discards: [0; TILE_TYPES],
            last_draw: None,
            can_discard: false,
        })
    }

    fn add_to_hand(&mut self, tile: Tile) -> AppResult<()> {
        if self.hand[tile.index] + self.discards[tile.index] >= 4 {
            return Err(format!("too many visible copies of {}", tile_name(tile)).into());
        }
        if tile.red {
            let suit = red_suit(tile.index).expect("red tile is a five");
            // This demo assumes the common ruleset with at most one red five per suit.
            if self.red_fives[suit] != 0 || self.red_discards[suit] != 0 {
                return Err("duplicate visible red five".into());
            }
            self.red_fives[suit] += 1;
        }
        self.hand[tile.index] += 1;
        Ok(())
    }

    fn remove_from_hand(&mut self, tile: Tile) -> AppResult<()> {
        let count = self.hand[tile.index];
        let red_count = red_suit(tile.index).map_or(0, |s| self.red_fives[s]);
        if count == 0 || (tile.red && red_count == 0) || (!tile.red && count == red_count) {
            return Err(format!("discarded tile {} is not in own hand", tile_name(tile)).into());
        }
        if tile.red {
            self.red_fives[red_suit(tile.index).expect("red tile is a five")] -= 1;
        }
        self.hand[tile.index] -= 1;
        Ok(())
    }

    fn apply(&mut self, event: Event) -> AppResult<()> {
        match event {
            Event::StartGame { id } => {
                // A protocol-supplied id identifies our own seat; otherwise
                // retain the --seat value (or the default seat 0).
                *self = Self::new(id.unwrap_or(self.seat))?;
            }
            Event::EndKyoku {} | Event::EndGame {} => {
                *self = Self::new(self.seat)?;
            }
            Event::StartKyoku { tehais } => {
                // Build the new state first, so invalid starting hands do not
                // leave a partially applied state behind.
                let mut next = Self::new(self.seat)?;
                for pai in &tehais[usize::from(self.seat)] {
                    if pai == "?" { return Err("own starting hand cannot contain '?'".into()); }
                    next.add_to_hand(parse_tile(pai)?)?;
                }
                *self = next;
            }
            Event::Tsumo { actor, pai } => {
                if actor > 3 { return Err("actor must be in 0..=3".into()); }
                if self.last_draw.is_some() {
                    return Err("received a draw before the previous own draw was discarded".into());
                }
                self.can_discard = false;
                if actor == self.seat {
                    if pai == "?" { return Err("own draw cannot be '?'".into()); }
                    let tile = parse_tile(&pai)?;
                    self.add_to_hand(tile)?;
                    self.last_draw = Some(tile);
                    self.can_discard = true;
                } else if pai != "?" {
                    parse_tile(&pai)?; // validate, but an opponent's hand is not tracked
                }
            }
            Event::Dahai { actor, pai, tsumogiri } => {
                if actor > 3 { return Err("actor must be in 0..=3".into()); }
                let tile = parse_tile(&pai)?;
                if actor != self.seat && self.last_draw.is_some() {
                    return Err("received an opponent discard before own draw was discarded".into());
                }
                if self.discards[tile.index] >= 4 {
                    return Err(format!("too many discarded copies of {}", tile_name(tile)).into());
                }
                if tile.red {
                    let suit = red_suit(tile.index).expect("red tile is a five");
                    let own_visible = if actor == self.seat { 0 } else { self.red_fives[suit] };
                    if self.red_discards[suit] + own_visible != 0 {
                        return Err("duplicate visible red five".into());
                    }
                }
                if actor == self.seat {
                    if tsumogiri && self.last_draw != Some(tile) {
                        return Err("tsumogiri does not match the last own draw".into());
                    }
                    self.remove_from_hand(tile)?;
                    self.last_draw = None;
                } else if self.hand[tile.index] + self.discards[tile.index] >= 4 {
                    return Err(format!("too many visible copies of {}", tile_name(tile)).into());
                }
                self.discards[tile.index] += 1;
                if tile.red { self.red_discards[red_suit(tile.index).unwrap()] += 1; }
                self.can_discard = false;
            }
            Event::None {} => {} // No new information; preserve any pending decision.
        }
        Ok(())
    }
}

// Demo-only encoding. The 9-wide dimension is a placeholder, not Mortal's.
// ch0: one-hot-ish cumulative own tile counts in columns 0..4.
// ch1: red-five count in column 0, at each five's tile index.
// ch2: last own draw, if any, at column 0.
// ch3: cumulative visible discard count in columns 0..4.
fn extract_features(state: &GameState) -> FeatureTensor {
    let mut features = [[[0.0_f32; WIDTH]; TILE_TYPES]; CHANNELS];
    for tile in 0..TILE_TYPES {
        for copy in 0..usize::from(state.hand[tile]) { features[0][tile][copy] = 1.0; }
        for copy in 0..usize::from(state.discards[tile]) { features[3][tile][copy] = 1.0; }
        if let Some(suit) = red_suit(tile) {
            features[1][tile][0] = f32::from(state.red_fives[suit]);
        }
    }
    if let Some(tile) = state.last_draw { features[2][tile.index][0] = 1.0; }
    features
}

fn flat_view(features: &FeatureTensor) -> &[f32] {
    // SAFETY: Rust arrays store their initialized elements contiguously; nested
    // arrays have no padding between f32 elements. The pointer is aligned for
    // f32, ELEMENTS is their exact number, and the returned borrow cannot outlive
    // or mutate `features`. No allocation or element copy occurs in this view.
    unsafe { std::slice::from_raw_parts(features.as_ptr().cast::<f32>(), ELEMENTS) }
}

fn mock_scores(features: &FeatureTensor) -> [f32; TILE_TYPES] {
    let view = flat_view(features);
    let first = &features[0][0][0] as *const f32;
    assert_eq!(view.as_ptr(), first, "flat view must borrow the array");
    eprintln!("mock input shape: {INPUT_SHAPE:?}; elements: {}; bytes: {}", view.len(), std::mem::size_of_val(view));
    eprintln!("array pointer: {first:p}; flat view pointer: {:p}; same allocation: {}", view.as_ptr(), first == view.as_ptr());
    eprintln!("mock checks the Rust view only; ONNX Runtime is not loaded");
    let mut scores = [0.0_f32; TILE_TYPES];
    for tile in 0..TILE_TYPES {
        scores[tile] = features[0][tile].iter().sum();
    }
    scores
}

fn onnx_scores(model_path: &Path, features: &FeatureTensor) -> AppResult<[f32; TILE_TYPES]> {
    let mut session = Session::builder()?
        .with_optimization_level(GraphOptimizationLevel::Level3)?
        .commit_from_file(model_path)?;
    if session.inputs.len() != 1 || session.outputs.len() != 1 {
        return Err(format!("demo expects one input and one output; model has {} input(s) and {} output(s)", session.inputs.len(), session.outputs.len()).into());
    }
    let flat = flat_view(features);
    // TensorRef borrows this CPU buffer; unlike an owned tensor constructor it
    // does not need to copy the f32 elements into a new input array. Keep
    // features alive and unchanged through run(). ORT may still copy internally,
    // especially for a non-CPU execution provider.
    let input = TensorRef::from_array_view((INPUT_SHAPE, flat))?;
    let outputs = session.run(ort::inputs![input])?;
    let (shape, values) = outputs[0].try_extract_tensor::<f32>()?;
    if **shape != OUTPUT_SHAPE || values.len() != TILE_TYPES {
        return Err(format!("demo expects f32 output shape {OUTPUT_SHAPE:?}; got {shape:?}").into());
    }
    let mut scores = [0.0_f32; TILE_TYPES];
    scores.copy_from_slice(values);
    Ok(scores)
}

#[derive(Serialize)]
#[serde(tag = "type", rename_all = "snake_case")]
enum Response {
    None {},
    Dahai { actor: u8, pai: &'static str, tsumogiri: bool },
}

fn choose_response(state: &GameState, scores: &[f32; TILE_TYPES]) -> AppResult<Response> {
    if !state.can_discard { return Ok(Response::None {}); }
    let mut best: Option<(usize, f32)> = None;
    for (index, &score) in scores.iter().enumerate() {
        // This only masks categories absent from the hand; a real model needs
        // the complete ruleset's legal-action mask and its own action mapping.
        if state.hand[index] == 0 || !score.is_finite() { continue; }
        if best.map_or(true, |(_, previous)| score > previous) { best = Some((index, score)); }
    }
    let (index, _) = best.ok_or("no finite score for a tile in the hand")?;
    // When the chosen category is the just-drawn physical tile, explicitly
    // choose that physical tile and set tsumogiri=true. Otherwise prefer an
    // ordinary five; use the red five if it is the only copy in that category.
    let (tile, tsumogiri) = match state.last_draw {
        Some(draw) if draw.index == index => (draw, true),
        _ => {
            let red = red_suit(index).map_or(false, |s| state.red_fives[s] == state.hand[index]);
            (Tile { index, red }, false)
        }
    };
    // A proposal does not mutate the state: a later input dahai event does that.
    Ok(Response::Dahai { actor: state.seat, pai: tile_name(tile), tsumogiri })
}

fn usage() {
    eprintln!("Usage: mjai-ort-phase1 [--seat 0..3] [--model model.onnx | model.onnx]\n\
               Pipe one MJAI JSON object per line; inference runs once at EOF.\n\
               Empty input uses a small built-in tsumo example; no model uses mock inference.");
}

fn run() -> AppResult<()> {
    let mut args = env::args().skip(1);
    let mut seat = 0_u8;
    let mut model: Option<String> = None;
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => { usage(); return Ok(()); }
            "--seat" => seat = args.next().ok_or("--seat requires a value")?.parse()?,
            "--model" => {
                let path = args.next().ok_or("--model requires a path")?;
                if model.replace(path).is_some() { return Err("model specified more than once".into()); }
            }
            _ if arg.starts_with('-') => return Err(format!("unknown argument: {arg}").into()),
            _ => if model.replace(arg).is_some() { return Err("model specified more than once".into()); },
        }
    }

    let mut state = GameState::new(seat)?;
    let stdin = io::stdin();
    let mut events_read = 0_usize;
    if !stdin.is_terminal() {
        for (line_number, line) in stdin.lock().lines().enumerate() {
            let line = line?;
            if line.trim().is_empty() { continue; }
            let event: Event = serde_json::from_str(&line)
                .map_err(|error| format!("line {}: {error}", line_number + 1))?;
            state.apply(event).map_err(|error| format!("line {}: {error}", line_number + 1))?;
            events_read += 1;
        }
    }
    if events_read == 0 {
        eprintln!("using built-in sample draw (no input events)");
        state.apply(Event::Tsumo { actor: seat, pai: "1m".to_owned() })?;
    }

    let response = if state.can_discard {
        let features = extract_features(&state);
        let scores = match model {
            Some(path) => onnx_scores(Path::new(&path), &features)?,
            None => mock_scores(&features),
        };
        choose_response(&state, &scores)?
    } else {
        Response::None {}
    };
    // Only MJAI JSON goes to stdout; diagnostics go to stderr.
    println!("{}", serde_json::to_string(&response)?);
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("error: {error}");
        std::process::exit(1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_tiles_and_rejects_bad_red_fives() {
        assert_eq!(parse_tile("1m").unwrap(), Tile { index: 0, red: false });
        assert_eq!(parse_tile("5pr").unwrap(), Tile { index: 13, red: true });
        assert_eq!(parse_tile("C").unwrap().index, 33);
        for invalid in ["?", "0m", "1mr", "5xr", "10m", "", "🀄"] {
            assert!(parse_tile(invalid).is_err(), "accepted {invalid}");
        }
    }

    #[test]
    fn features_are_contiguous_and_match_multidimensional_indices() {
        let mut state = GameState::new(0).unwrap();
        state.apply(Event::Tsumo { actor: 0, pai: "5mr".into() }).unwrap();
        let features = extract_features(&state);
        let flat = flat_view(&features);
        assert_eq!(flat.len(), ELEMENTS);
        assert_eq!(flat.as_ptr(), &features[0][0][0] as *const f32);
        for channel in 0..CHANNELS {
            for tile in 0..TILE_TYPES {
                for column in 0..WIDTH {
                    assert_eq!(flat[(channel * TILE_TYPES + tile) * WIDTH + column], features[channel][tile][column]);
                }
            }
        }
        assert_eq!(features[0][4][0], 1.0);
        assert_eq!(features[1][4][0], 1.0);
        assert_eq!(features[2][4][0], 1.0);
    }

    #[test]
    fn red_and_nonred_counts_and_proposed_discard_stay_consistent() {
        let mut state = GameState::new(0).unwrap();
        state.add_to_hand(parse_tile("5m").unwrap()).unwrap();
        state.apply(Event::Tsumo { actor: 0, pai: "5mr".into() }).unwrap();
        let mut scores = [0.0; TILE_TYPES];
        scores[4] = 5.0;
        let response = choose_response(&state, &scores).unwrap();
        assert_eq!(serde_json::to_string(&response).unwrap(), r#"{"type":"dahai","actor":0,"pai":"5mr","tsumogiri":true}"#);
        assert_eq!(state.hand[4], 2); // merely proposing a move does not remove it
        state.apply(Event::Dahai { actor: 0, pai: "5mr".into(), tsumogiri: true }).unwrap();
        assert_eq!(state.hand[4], 1);
        assert_eq!(state.red_fives[0], 0);
        assert_eq!(state.discards[4], 1);
        assert!(state.remove_from_hand(parse_tile("5mr").unwrap()).is_err());
    }

    #[test]
    fn rejects_unsupported_events_instead_of_losing_sync() {
        assert!(serde_json::from_str::<Event>(r#"{"type":"pon","actor":0,"pai":"1m"}"#).is_err());
        assert!(serde_json::from_str::<Event>(r#"{"type":"dahai","actor":0,"pai":"1m"}"#).is_err());
    }

    #[test]
    fn protocol_seat_and_none_preserve_pending_draw() {
        let mut state = GameState::new(0).unwrap();
        let start: Event = serde_json::from_str(r#"{"type":"start_game","id":1}"#).unwrap();
        state.apply(start).unwrap();
        assert_eq!(state.seat, 1);
        state.apply(Event::Tsumo { actor: 1, pai: "1m".into() }).unwrap();
        state.apply(Event::None {}).unwrap();
        assert!(state.can_discard);
        assert_eq!(state.last_draw, Some(parse_tile("1m").unwrap()));
        assert!(state.apply(Event::Dahai { actor: 1, pai: "2m".into(), tsumogiri: true }).is_err());
    }

    #[test]
    fn rejects_a_second_visible_red_five() {
        let mut state = GameState::new(0).unwrap();
        state.add_to_hand(parse_tile("5mr").unwrap()).unwrap();
        assert!(state.apply(Event::Dahai { actor: 1, pai: "5mr".into(), tsumogiri: false }).is_err());
    }
}
