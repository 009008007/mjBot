The test fixture `tests/fixtures/akagi_restore_new_round.bin` is decoded from an Akagi v3 test fixture.

Akagi v3 — Copyright 2026 Shinkuan. Licensed under the Apache License, Version 2.0. A copy of that license is provided as `Apache-2.0.txt`.

Source and upstream notices:
- https://github.com/shinkuan/Akagi/blob/v3/src/bridge/majsoul/parser.rs
- https://github.com/shinkuan/Akagi/blob/v3/NOTICE
