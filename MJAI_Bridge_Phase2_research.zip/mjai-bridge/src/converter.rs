//! Convert a deliberately limited subset of Mahjong Soul into MJAI.
//!
//! The public gameplay schema uses *strings* such as `0m` and `1z` on the
//! wire, not tile IDs. `tile_id_to_mjai` is an additional 34-index helper.
//! ActionPrototype.data must be deobfuscated by the framing layer before this
//! module is called. A missing or unsupported state-changing action quarantines
//! the incremental stream until a subsequent valid `ActionNewRound`.

use prost::Message;
use serde::Serialize;

use crate::{
    majsoul_proto::{ActionDealTile, ActionDiscardTile, ActionNewRound, ActionPrototype},
    state::BridgeState,
};

const TILE_NAMES: [&str; 34] = [
    "1m", "2m", "3m", "4m", "5m", "6m", "7m", "8m", "9m",
    "1p", "2p", "3p", "4p", "5p", "6p", "7p", "8p", "9p",
    "1s", "2s", "3s", "4s", "5s", "6s", "7s", "8s", "9s",
    "E", "S", "W", "N", "P", "F", "C",
];

/// Convert a 0-based 34-tile index to MJAI. Invalid IDs or an invalid red flag
/// are errors: no guessed or misleading output is returned.
pub fn tile_id_to_mjai(id: i32, is_red: bool) -> Result<String, String> {
    let index = usize::try_from(id).map_err(|_| format!("invalid tile id {id}"))?;
    let name = TILE_NAMES.get(index).ok_or_else(|| format!("invalid tile id {id}"))?;
    if is_red {
        if !matches!(index, 4 | 13 | 22) {
            return Err(format!("red flag is invalid for tile id {id}"));
        }
        return Ok(format!("{name}r"));
    }
    Ok((*name).to_owned())
}

fn parse_majsoul_tile(tile: &str) -> Result<(i32, bool), String> {
    let bytes = tile.as_bytes();
    if bytes.len() != 2 {
        return Err(format!("invalid Mahjong Soul tile {tile:?}"));
    }
    let rank = bytes[0];
    let suit = bytes[1];
    match suit {
        b'm' | b'p' | b's' => {
            let base: i32 = match suit { b'm' => 0, b'p' => 9, _ => 18 };
            if rank == b'0' {
                Ok((base + 4, true))
            } else if (b'1'..=b'9').contains(&rank) {
                Ok((base + i32::from(rank - b'1'), false))
            } else {
                Err(format!("invalid Mahjong Soul tile {tile:?}"))
            }
        }
        b'z' if (b'1'..=b'7').contains(&rank) => Ok((27 + i32::from(rank - b'1'), false)),
        _ => Err(format!("invalid Mahjong Soul tile {tile:?}")),
    }
}

pub fn majsoul_tile_to_mjai(tile: &str) -> Result<String, String> {
    let (id, red) = parse_majsoul_tile(tile)?;
    tile_id_to_mjai(id, red)
}

#[derive(Debug, Serialize, PartialEq, Eq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum MjaiEvent {
    StartGame { id: u8 },
    StartKyoku {
        bakaze: &'static str,
        kyoku: u32,
        honba: u32,
        kyotaku: u32,
        oya: u8,
        dora_marker: String,
        scores: [i32; 4],
        tehais: [Vec<String>; 4],
    },
    Tsumo { actor: u8, pai: String },
    Dahai { actor: u8, pai: String, tsumogiri: bool },
}

fn seat(id: u32) -> Result<u8, String> {
    if id > 3 { return Err(format!("invalid seat {id}; only four-player games are supported")); }
    Ok(id as u8)
}

/// Ensure that no newly exposed dora indicator is silently lost. Phase 1
/// cannot consume the MJAI `dora` event, so changes require quarantine.
fn validate_doras(state: &BridgeState, wire_doras: &[String]) -> Result<(), String> {
    if wire_doras.is_empty() { return Ok(()); }
    let known = state.dora_marker.as_ref().ok_or("missing round dora")?;
    if wire_doras.len() != 1 || majsoul_tile_to_mjai(&wire_doras[0])? != *known {
        return Err("dora indicators changed; Phase 1 does not support dora events".into());
    }
    Ok(())
}

fn start_round(state: &mut BridgeState, data: &[u8], step: u32) -> Result<Vec<MjaiEvent>, String> {
    let round = ActionNewRound::decode(data).map_err(|e| format!("ActionNewRound protobuf: {e}"))?;
    // Ordinary captures may include one empty `opens` entry per seat. Only
    // reject entries carrying actual open tiles/counts or special-mode state.
    if round.opens.iter().any(|opened| !opened.tiles.is_empty() || !opened.count.is_empty())
        || round.muyu.is_some() || round.field_spell != 0 || round.yongchang.is_some()
    {
        return Err("round contains unsupported opening/special-mode state".into());
    }
    let bakaze = match round.chang {
        0 => "E", 1 => "S", 2 => "W", 3 => "N",
        n => return Err(format!("invalid round wind {n}")),
    };
    let oya = seat(round.ju)?;
    if round.tiles.len() == 14 {
        // The live protocol does not identify which of these 14 tiles was the
        // initial physical draw. Inventing one corrupts tsumogiri semantics.
        return Err("local dealer has 14 initial tiles and the first draw is not identified; waiting for a later round".into());
    }
    if round.tiles.len() != 13 {
        return Err(format!("expected 13 visible own starting tiles, received {}", round.tiles.len()));
    }
    if oya == state.seat {
        return Err("local dealer normally starts with 14 tiles; this 13-tile snapshot is incomplete".into());
    }

    let mut counts = [0_u8; 34];
    let mut red_fives = [false; 3];
    let mut own_hand = Vec::with_capacity(13);
    for wire in &round.tiles {
        let (id, red) = parse_majsoul_tile(wire)?;
        let index = id as usize;
        counts[index] += 1;
        if counts[index] > 4 { return Err(format!("starting hand has too many {wire} tiles")); }
        if red {
            let suit = index / 9;
            if red_fives[suit] { return Err(format!("duplicate red five {wire}")); }
            red_fives[suit] = true;
        }
        own_hand.push(tile_id_to_mjai(id, red)?);
    }

    let dora_wire = if let Some(first) = round.doras.first() {
        if round.doras.len() != 1 {
            return Err("multiple starting dora indicators are unsupported".into());
        }
        if !round.dora.is_empty() && round.dora != *first {
            return Err("conflicting dora and doras fields".into());
        }
        first.as_str()
    } else if !round.dora.is_empty() {
        round.dora.as_str()
    } else {
        return Err("missing starting dora indicator".into());
    };
    let dora = majsoul_tile_to_mjai(dora_wire)?;
    if round.scores.len() != 4 {
        return Err(format!("expected four scores, received {}; only four-player games are supported", round.scores.len()));
    }
    let scores = [round.scores[0], round.scores[1], round.scores[2], round.scores[3]];
    let mut tehais: [Vec<String>; 4] = std::array::from_fn(|_| vec!["?".to_owned(); 13]);
    tehais[usize::from(state.seat)] = own_hand;
    let mut events = Vec::with_capacity(3);
    if !state.announced {
        events.push(MjaiEvent::StartGame { id: state.seat });
    }
    events.push(MjaiEvent::StartKyoku {
        bakaze,
        kyoku: round.ju + 1,
        honba: round.ben,
        kyotaku: round.liqibang,
        oya,
        dora_marker: dora.clone(),
        scores,
        tehais,
    });
    // The dealer's 14th opening tile is hidden to this nondealer client.
    // Emit an unknown draw to express the MJAI action sequence without guessing
    // its identity. The local player's initial 13 tiles remain exact.
    events.push(MjaiEvent::Tsumo { actor: oya, pai: "?".to_owned() });
    state.announced = true;
    state.active = true;
    state.last_step = Some(step);
    state.dora_marker = Some(dora);
    Ok(events)
}

fn convert_inner(state: &mut BridgeState, action: &ActionPrototype) -> Result<Vec<MjaiEvent>, String> {
    let name = action.name.strip_prefix(".lq.").unwrap_or(&action.name);
    if name == "ActionNewRound" {
        return start_round(state, action.data.as_ref(), action.step);
    }
    if name == "ActionMJStart" {
        if state.active { return Err("unexpected ActionMJStart during a round".into()); }
        state.announced = false;
        return Ok(Vec::new());
    }
    if !state.active {
        return Err(format!("cannot map {name}: waiting for a complete, supported ActionNewRound"));
    }
    let expected = state.last_step.and_then(|n| n.checked_add(1)).ok_or("missing/overflowing action step")?;
    if action.step != expected {
        return Err(format!("action step gap: expected {expected}, received {}", action.step));
    }
    let event = match name {
        "ActionDealTile" => {
            let draw = ActionDealTile::decode(action.data.as_ref()).map_err(|e| format!("ActionDealTile protobuf: {e}"))?;
            // The payload can report an accepted riichi along with this draw.
            // Phase 1 cannot process the required reach_accepted event, so do
            // not silently discard the state change.
            if draw.liqi.is_some() {
                return Err("draw includes riichi acceptance, which Phase 1 does not support".into());
            }
            if draw.tile_state != 0 || draw.muyu.is_some() {
                return Err("draw contains unsupported special-mode state".into());
            }
            validate_doras(state, &draw.doras)?;
            let actor = seat(draw.seat)?;
            let pai = if draw.tile.is_empty() {
                if actor == state.seat { return Err("own draw has no visible tile".into()); }
                "?".to_owned()
            } else {
                majsoul_tile_to_mjai(&draw.tile)?
            };
            MjaiEvent::Tsumo { actor, pai }
        }
        "ActionDiscardTile" => {
            let discard = ActionDiscardTile::decode(action.data.as_ref()).map_err(|e| format!("ActionDiscardTile protobuf: {e}"))?;
            validate_doras(state, &discard.doras)?;
            if discard.tile_state != 0 || discard.muyu.is_some() || discard.revealed || discard.yongchang.is_some() {
                return Err("discard contains unsupported special-mode state".into());
            }
            if discard.is_liqi || discard.is_wliqi {
                return Err("riichi discard requires unsupported MJAI reach events".into());
            }
            MjaiEvent::Dahai { actor: seat(discard.seat)?, pai: majsoul_tile_to_mjai(&discard.tile)?, tsumogiri: discard.moqie }
        }
        _ => return Err(format!("unsupported action {name}; state is no longer reliable")),
    };
    state.last_step = Some(action.step);
    Ok(vec![event])
}

/// Convert one deobfuscated action. A decode/mapping error never panics and
/// invalidates the incremental state; caller logs the error and forwards the
/// unmodified WebSocket frame independently.
pub fn convert_action(state: &mut BridgeState, action: ActionPrototype) -> Result<Vec<MjaiEvent>, String> {
    let result = convert_inner(state, &action);
    if result.is_err() { state.desynchronize(); }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    fn action<M: Message>(step: u32, name: &str, payload: &M) -> ActionPrototype {
        ActionPrototype { step, name: name.to_owned(), data: payload.encode_to_vec().into() }
    }

    fn round() -> ActionNewRound {
        ActionNewRound {
            chang: 0,
            ju: 0,
            ben: 0,
            tiles: ["1m", "2m", "3m", "4m", "0m", "6m", "7m", "8m", "9m", "1p", "2p", "3p", "1z"].iter().map(|x| (*x).to_owned()).collect(),
            dora: "".into(),
            doras: vec!["2z".into()],
            scores: vec![25000; 4],
            ..Default::default()
        }
    }

    #[test]
    fn tile_ids_and_wire_strings_are_mapped_exactly() {
        assert_eq!(tile_id_to_mjai(0, false).unwrap(), "1m");
        assert_eq!(tile_id_to_mjai(4, true).unwrap(), "5mr");
        assert_eq!(tile_id_to_mjai(13, true).unwrap(), "5pr");
        assert_eq!(tile_id_to_mjai(22, true).unwrap(), "5sr");
        for (i, name) in ["E", "S", "W", "N", "P", "F", "C"].iter().enumerate() {
            assert_eq!(majsoul_tile_to_mjai(&format!("{}z", i + 1)).unwrap(), *name);
        }
        assert_eq!(majsoul_tile_to_mjai("0s").unwrap(), "5sr");
        for bad in ["", "10m", "8z", "0z", "?", "1x", "🀄"] {
            assert!(majsoul_tile_to_mjai(bad).is_err(), "accepted {bad}");
        }
        assert!(tile_id_to_mjai(-1, false).is_err());
        assert!(tile_id_to_mjai(34, false).is_err());
        assert!(tile_id_to_mjai(0, true).is_err());
    }

    #[test]
    fn round_draw_and_discard_are_phase1_compatible_json() {
        let mut state = BridgeState::new(1).unwrap();
        let events = convert_action(&mut state, action(1, "ActionNewRound", &round())).unwrap();
        assert_eq!(events.len(), 3);
        let start = serde_json::to_value(&events[1]).unwrap();
        assert_eq!(start["type"], "start_kyoku");
        assert_eq!(start["bakaze"], "E");
        assert_eq!(start["kyoku"], 1);
        assert_eq!(start["oya"], 0);
        assert_eq!(start["dora_marker"], "S");
        assert_eq!(start["tehais"][1][4], "5mr");
        assert_eq!(start["tehais"][0][0], "?");
        assert_eq!(serde_json::to_value(&events[2]).unwrap(), serde_json::json!({"type":"tsumo","actor":0,"pai":"?"}));
        let discard = ActionDiscardTile { seat: 0, tile: "2z".into(), moqie: false, ..Default::default() };
        let e = convert_action(&mut state, action(2, "ActionDiscardTile", &discard)).unwrap();
        assert_eq!(serde_json::to_value(&e[0]).unwrap(), serde_json::json!({"type":"dahai","actor":0,"pai":"S","tsumogiri":false}));
        let draw = ActionDealTile { seat: 1, tile: "0p".into(), ..Default::default() };
        let e = convert_action(&mut state, action(3, "ActionDealTile", &draw)).unwrap();
        assert_eq!(serde_json::to_value(&e[0]).unwrap(), serde_json::json!({"type":"tsumo","actor":1,"pai":"5pr"}));
    }

    #[test]
    fn unsupported_action_or_step_gap_quarantines_until_new_round() {
        let mut state = BridgeState::new(1).unwrap();
        convert_action(&mut state, action(1, "ActionNewRound", &round())).unwrap();
        let unknown = ActionPrototype { step: 2, name: "ActionChiPengGang".into(), data: Default::default() };
        assert!(convert_action(&mut state, unknown).is_err());
        assert!(!state.active);
        let draw = ActionDealTile { seat: 1, tile: "5m".into(), ..Default::default() };
        assert!(convert_action(&mut state, action(3, "ActionDealTile", &draw)).is_err());
        let recovered = convert_action(&mut state, action(0, "ActionNewRound", &round())).unwrap();
        assert_eq!(serde_json::to_value(&recovered[0]).unwrap(), serde_json::json!({"type":"start_game","id":1}));
        assert!(convert_action(&mut state, action(2, "ActionDealTile", &draw)).is_err());
        assert!(!state.active);
    }

    #[test]
    fn local_dealer_14_tile_start_is_not_fabricated() {
        let mut state = BridgeState::new(0).unwrap();
        let mut deal = round();
        deal.tiles.push("4p".into());
        assert!(convert_action(&mut state, action(1, "ActionNewRound", &deal)).is_err());
        assert!(!state.active);
    }

    #[test]
    fn incomplete_or_three_player_scores_cannot_start_four_player_state() {
        let mut state = BridgeState::new(1).unwrap();
        let mut deal = round();
        deal.scores.clear();
        assert!(convert_action(&mut state, action(0, "ActionNewRound", &deal)).is_err());
        deal.scores = vec![25000; 3];
        assert!(convert_action(&mut state, action(0, "ActionNewRound", &deal)).is_err());
        assert!(!state.active);
    }

    #[test]
    fn unknown_own_draw_riichi_and_new_dora_quarantine() {
        let mut state = BridgeState::new(1).unwrap();
        convert_action(&mut state, action(1, "ActionNewRound", &round())).unwrap();
        let hidden_self = ActionDealTile { seat: 1, tile: String::new(), ..Default::default() };
        assert!(convert_action(&mut state, action(2, "ActionDealTile", &hidden_self)).is_err());
        convert_action(&mut state, action(0, "ActionNewRound", &round())).unwrap();
        let riichi = ActionDiscardTile { seat: 0, tile: "1m".into(), is_liqi: true, ..Default::default() };
        assert!(convert_action(&mut state, action(1, "ActionDiscardTile", &riichi)).is_err());
        convert_action(&mut state, action(0, "ActionNewRound", &round())).unwrap();
        let new_dora = ActionDealTile { seat: 0, tile: String::new(), doras: vec!["2z".into(), "3z".into()], ..Default::default() };
        assert!(convert_action(&mut state, action(1, "ActionDealTile", &new_dora)).is_err());
    }

    #[test]
    fn riichi_acceptance_on_draw_quarantines_instead_of_being_ignored() {
        let mut state = BridgeState::new(1).unwrap();
        convert_action(&mut state, action(1, "ActionNewRound", &round())).unwrap();
        let draw = ActionDealTile {
            seat: 1,
            tile: "1m".into(),
            liqi: Some(Default::default()),
            ..Default::default()
        };
        let error = convert_action(&mut state, action(2, "ActionDealTile", &draw)).unwrap_err();
        assert!(error.contains("riichi acceptance"));
        assert!(!state.active);
    }

    #[test]
    fn round_allows_seat_only_opens_but_quarantines_special_state() {
        let mut state = BridgeState::new(1).unwrap();
        let mut deal = round();
        deal.opens.resize_with(4, Default::default);
        for (seat, opened) in deal.opens.iter_mut().enumerate() {
            opened.seat = seat as u32;
        }
        assert!(convert_action(&mut state, action(1, "ActionNewRound", &deal)).is_ok());
        deal.opens[2].tiles.push("1m".into());
        assert!(convert_action(&mut state, action(0, "ActionNewRound", &deal)).is_err());
        assert!(!state.active);
        deal.opens[2].tiles.clear();
        deal.opens[2].count.push(1);
        assert!(convert_action(&mut state, action(0, "ActionNewRound", &deal)).is_err());
        deal.opens[2].count.clear();
        deal.field_spell = 1;
        assert!(convert_action(&mut state, action(0, "ActionNewRound", &deal)).is_err());
    }

    #[test]
    fn special_draw_and_discard_quarantine() {
        let mut state = BridgeState::new(1).unwrap();
        convert_action(&mut state, action(0, "ActionNewRound", &round())).unwrap();
        let draw = ActionDealTile { seat: 1, tile: "1m".into(), tile_state: 1, ..Default::default() };
        assert!(convert_action(&mut state, action(1, "ActionDealTile", &draw)).is_err());
        assert!(!state.active);
        convert_action(&mut state, action(0, "ActionNewRound", &round())).unwrap();
        let discard = ActionDiscardTile { seat: 0, tile: "1m".into(), revealed: true, ..Default::default() };
        assert!(convert_action(&mut state, action(1, "ActionDiscardTile", &discard)).is_err());
        assert!(!state.active);
    }
}
