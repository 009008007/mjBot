mod converter;
mod proxy;
mod state;

pub mod majsoul_proto {
    include!(concat!(env!("OUT_DIR"), "/lq.rs"));
}

use std::{env, error::Error, net::SocketAddr};

type AppResult<T> = Result<T, Box<dyn Error + Send + Sync>>;

fn usage() {
    eprintln!("Usage: mjai-bridge --upstream <ws[s]://server/path> --seat <0..3> [--listen <loopback:port>]\n\
        Example: mjai-bridge --upstream wss://example.invalid/game-gateway --seat 0\n\
        The client must explicitly connect to the local proxy; the proxy does not\n\
        redirect an existing WSS connection. MJAI JSON goes to stdout.");
}

#[tokio::main]
async fn main() -> AppResult<()> {
    let mut args = env::args().skip(1);
    let mut upstream: Option<String> = None;
    let mut seat: Option<u8> = None;
    let mut listen = String::from("127.0.0.1:12121");
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => { usage(); return Ok(()); }
            "--upstream" => {
                if upstream.is_some() { return Err("--upstream specified twice".into()); }
                upstream = Some(args.next().ok_or("--upstream requires a URL")?);
            }
            "--seat" => {
                if seat.is_some() { return Err("--seat specified twice".into()); }
                let value: u8 = args.next().ok_or("--seat requires a value")?.parse()?;
                if value > 3 { return Err("--seat must be in 0..=3".into()); }
                seat = Some(value);
            }
            "--listen" => listen = args.next().ok_or("--listen requires an address")?,
            _ => return Err(format!("unknown argument: {arg}").into()),
        }
    }
    let upstream = upstream.ok_or("--upstream is required; use --help")?;
    if !(upstream.starts_with("ws://") || upstream.starts_with("wss://")) {
        return Err("--upstream must be a ws:// or wss:// URL".into());
    }
    let seat = seat.ok_or("--seat is required; use --help")?;
    let bind_addr: SocketAddr = listen.parse()?;
    if !bind_addr.ip().is_loopback() { return Err("--listen must be a loopback address".into()); }
    // Explicit installation avoids rustls provider ambiguity when dependencies
    // enable multiple providers. Ignore only the already-installed case.
    let _ = rustls::crypto::ring::default_provider().install_default();
    proxy::run(&listen, &upstream, seat).await
}
