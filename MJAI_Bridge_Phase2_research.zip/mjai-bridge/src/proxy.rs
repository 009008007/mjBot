//! Local WebSocket relay and Liqi notification decoder.
//!
//! The client must explicitly connect to this listener. This module does not
//! redirect an existing browser/game connection or terminate its TLS traffic.
//! Application text/binary messages are forwarded unchanged; ping/pong are
//! handled independently by each WebSocket endpoint. For a secure upstream,
//! compile tokio-tungstenite with the rustls feature and supply its wss:// URL.

use std::{error::Error, sync::{Arc, Mutex}, time::Duration};

use bytes::{Buf, Bytes};
use futures_util::{SinkExt, StreamExt};
use prost::Message as ProstMessage;
use tokio::{io::AsyncWriteExt, net::{TcpListener, TcpStream}, sync::mpsc, time::timeout};
use tokio_tungstenite::{
    accept_hdr_async, connect_async,
    tungstenite::{
        client::IntoClientRequest,
        handshake::server::{ErrorResponse, Request, Response},
        http::{header, HeaderMap, StatusCode},
        Message,
    },
};

use crate::{
    converter::convert_action,
    majsoul_proto::{ActionPrototype, Wrapper},
    state::BridgeState,
};

type BoxError = Box<dyn Error + Send + Sync>;

const ACTION_METHOD: &str = ".lq.ActionPrototype";
const MAX_ACTION_BYTES: usize = 1024 * 1024;
const LIVE_XOR_KEY: [u8; 9] = [0x84, 0x5e, 0x4e, 0x42, 0x39, 0xa2, 0x1f, 0x60, 0x1c];

/// Decode a live ActionPrototype body. Applying this function twice restores
/// the original bytes. Restore/sync action bodies use a different path and are
/// intentionally not handled here.
fn live_action_xor(body: &[u8]) -> Bytes {
    let base = 23_usize ^ body.len();
    let mut decoded = Vec::with_capacity(body.len());
    for (i, byte) in body.iter().copied().enumerate() {
        let mask = base.wrapping_add(i.wrapping_mul(5))
            .wrapping_add(usize::from(LIVE_XOR_KEY[i % LIVE_XOR_KEY.len()])) as u8;
        decoded.push(byte ^ mask);
    }
    Bytes::from(decoded)
}

/// Parse only server notifications. Request/response frames are not used to
/// infer seat or credentials and are deliberately ignored. The outer Bytes
/// slices share storage; the live XOR step necessarily creates a new buffer.
fn decode_live_frame(mut frame: Bytes) -> Result<Option<ActionPrototype>, &'static str> {
    if frame.is_empty() { return Err("empty Liqi frame"); }
    let kind = frame.get_u8();
    match kind {
        1 => {}
        2 | 3 => {
            if frame.len() < 2 { return Err("truncated request/response header"); }
            // The next two bytes are a little-endian request ID. No request
            // tracking is necessary for the supported notification-only path.
            return Ok(None);
        }
        _ => return Err("unknown Liqi frame type"),
    }

    let envelope = Wrapper::decode(frame).map_err(|_| "invalid Liqi wrapper")?;
    if envelope.name.is_empty() { return Err("notification without a method"); }
    if envelope.name != ACTION_METHOD { return Ok(None); }
    let mut action = ActionPrototype::decode(envelope.data)
        .map_err(|_| "invalid ActionPrototype")?;
    if action.data.len() > MAX_ACTION_BYTES { return Err("action body exceeds limit"); }
    action.data = live_action_xor(&action.data);
    Ok(Some(action))
}

fn process_server_binary(frame: Bytes, state: &mut BridgeState, tx: &mpsc::Sender<String>) {
    let action = match decode_live_frame(frame) {
        Ok(Some(action)) => action,
        Ok(None) => return,
        Err(reason) => {
            // A malformed notification could have contained a state change.
            // Keep relaying the original message but suppress subsequent
            // decisions until a supported new-round event re-establishes state.
            state.desynchronize();
            eprintln!("bridge: {reason}; event state is no longer synchronized");
            return;
        }
    };
    let events = match convert_action(state, action) {
        Ok(events) => events,
        Err(reason) => {
            state.desynchronize();
            eprintln!("bridge: action could not be mapped: {reason}");
            return;
        }
    };
    for event in events {
        let json = match serde_json::to_string(&event) {
            Ok(json) => json,
            Err(_) => {
                state.desynchronize();
                // The event announcing the local seat might be the one that
                // was lost, so send a fresh announcement at the next round.
                state.announced = false;
                eprintln!("bridge: failed to serialize an mjai event");
                return;
            }
        };
        // Never stall the WebSocket relay behind a slow or disconnected stdout
        // consumer. If a line cannot be delivered, future state cannot safely
        // be consumed until the next supported round start.
        if tx.try_send(json).is_err() {
            state.desynchronize();
            state.announced = false;
            eprintln!("bridge: mjai output unavailable or full; event state is no longer synchronized");
            return;
        }
    }
}

/// Accept a single local connection and relay it to the configured upstream.
/// Origin, Cookie and Authorization are passed through without being logged.
/// This minimal relay cannot negotiate a subprotocol on both legs atomically;
/// it rejects that request instead of falsely advertising transparency.
async fn relay_connection(socket: TcpStream, upstream_url: &str, seat: u8, tx: mpsc::Sender<String>) -> Result<(), BoxError> {
    let headers = Arc::new(Mutex::new(HeaderMap::new()));
    let captured = Arc::clone(&headers);
    let client_handshake = accept_hdr_async(socket, move |request: &Request, response: Response| {
        if request.headers().contains_key(header::SEC_WEBSOCKET_PROTOCOL) {
            let mut error = ErrorResponse::new(Some("WebSocket subprotocol negotiation is not supported by this relay".to_owned()));
            *error.status_mut() = StatusCode::BAD_REQUEST;
            return Err(error);
        }
        let mut saved = match captured.lock() {
            Ok(saved) => saved,
            Err(_) => {
                let mut error = ErrorResponse::new(Some("Unable to capture handshake headers".to_owned()));
                *error.status_mut() = StatusCode::INTERNAL_SERVER_ERROR;
                return Err(error);
            }
        };
        for name in [header::ORIGIN, header::COOKIE, header::AUTHORIZATION] {
            for value in request.headers().get_all(&name) {
                saved.append(name.clone(), value.clone());
            }
        }
        Ok(response)
    });
    let client = timeout(Duration::from_secs(15), client_handshake).await
        .map_err(|_| "local WebSocket handshake timed out")?
        .map_err(|_| "local WebSocket handshake failed")?;

    let mut request = upstream_url.into_client_request()
        .map_err(|_| "invalid upstream WebSocket URL")?;
    {
        let saved = headers.lock().map_err(|_| "handshake header lock unavailable")?;
        for name in [header::ORIGIN, header::COOKIE, header::AUTHORIZATION] {
            for value in saved.get_all(&name) {
                request.headers_mut().append(name.clone(), value.clone());
            }
        }
    }
    drop(headers);
    // Do not log the configured URL or handshake errors: either might include
    // sensitive headers or query parameters. The runtime validates wss TLS.
    let (upstream, response) = timeout(Duration::from_secs(15), connect_async(request)).await
        .map_err(|_| "upstream WebSocket handshake timed out")?
        .map_err(|_| "upstream WebSocket handshake failed")?;
    if response.headers().contains_key(header::SEC_WEBSOCKET_PROTOCOL) {
        return Err("unsolicited upstream WebSocket subprotocol is unsupported".into());
    }
    let mut state = BridgeState::new(seat).map_err(|_| "invalid local seat")?;
    let (mut client_sink, mut client_source) = client.split();
    let (mut server_sink, mut server_source) = upstream.split();

    loop {
        tokio::select! {
            client_message = client_source.next() => {
                match client_message {
                    Some(Ok(Message::Binary(data))) => server_sink.send(Message::Binary(data)).await?,
                    Some(Ok(Message::Text(data))) => server_sink.send(Message::Text(data)).await?,
                    Some(Ok(Message::Close(close))) => {
                        let _ = server_sink.send(Message::Close(close)).await;
                        break;
                    }
                    Some(Ok(Message::Ping(_) | Message::Pong(_))) => {},
                    Some(Ok(Message::Frame(_))) => {},
                    Some(Err(_)) => return Err("local WebSocket read failed".into()),
                    None => break,
                }
            }
            server_message = server_source.next() => {
                match server_message {
                    Some(Ok(Message::Binary(data))) => {
                        // Cloning Bytes only increments a refcount; it leaves the
                        // original payload untouched and avoids an input copy.
                        client_sink.send(Message::Binary(data.clone())).await?;
                        process_server_binary(data, &mut state, &tx);
                    }
                    Some(Ok(Message::Text(data))) => client_sink.send(Message::Text(data)).await?,
                    Some(Ok(Message::Close(close))) => {
                        let _ = client_sink.send(Message::Close(close)).await;
                        break;
                    }
                    Some(Ok(Message::Ping(_) | Message::Pong(_))) => {},
                    Some(Ok(Message::Frame(_))) => {},
                    Some(Err(_)) => return Err("upstream WebSocket read failed".into()),
                    None => break,
                }
            }
        }
    }
    Ok(())
}

/// Listen for one connection at a time, keeping each MJAI stream's state
/// separate. Diagnostics use stderr; stdout contains newline-delimited JSON.
pub async fn run(listen_addr: &str, upstream_url: &str, seat: u8) -> Result<(), BoxError> {
    // Validate seat before accepting a connection.
    BridgeState::new(seat).map_err(|_| "seat must be between 0 and 3")?;
    let listener = TcpListener::bind(listen_addr).await?;
    let (tx, mut rx) = mpsc::channel::<String>(512);
    tokio::spawn(async move {
        let mut output = tokio::io::BufWriter::new(tokio::io::stdout());
        while let Some(json) = rx.recv().await {
            if output.write_all(json.as_bytes()).await.is_err()
                || output.write_all(b"\n").await.is_err()
                || output.flush().await.is_err() {
                eprintln!("bridge: stdout closed");
                break;
            }
        }
    });
    eprintln!("bridge: listening on {listen_addr} (one active connection)");
    loop {
        let (socket, _) = listener.accept().await?;
        if let Err(error) = relay_connection(socket, upstream_url, seat, tx.clone()).await {
            eprintln!("bridge: connection ended: {error}");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use bytes::{BufMut, BytesMut};
    use crate::majsoul_proto::{ActionDealTile, ActionDiscardTile, ActionNewRound};
    use tokio::sync::oneshot;

    #[test]
    fn live_xor_is_reversible() {
        let input = b"example action bytes";
        assert_eq!(live_action_xor(&live_action_xor(input)).as_ref(), input);
    }

    #[test]
    fn captured_restore_payload_decodes_without_live_xor() {
        // Public Akagi RESTORE_NEW_ROUND_B64 fixture, not a live frame. Restore
        // payloads are already plain protobuf and must not receive live XOR.
        let round = ActionNewRound::decode(
            &include_bytes!("../tests/fixtures/akagi_restore_new_round.bin")[..],
        ).unwrap();
        assert_eq!(round.tiles.iter().map(String::as_str).collect::<Vec<_>>(),
            vec!["4p", "1m", "3p", "4z", "7z", "6z", "0p", "3s", "0m", "4s", "1s", "9s", "2z"]);
        assert_eq!(round.scores.as_slice(), &[25000, 25000, 25000, 25000]);
        assert_eq!(round.doras.iter().map(String::as_str).collect::<Vec<_>>(), vec!["1z"]);
        assert_eq!(round.opens.len(), 4);
        assert!(round.opens.iter().all(|open| open.tiles.is_empty() && open.count.is_empty()));
    }

    #[test]
    fn parses_notify_and_deobfuscates_action_body() {
        let deal = ActionDealTile { seat: 2, tile: "0m".to_owned(), ..Default::default() };
        let plaintext = deal.encode_to_vec();
        let action = ActionPrototype {
            step: 8,
            name: "ActionDealTile".to_owned(),
            data: live_action_xor(&plaintext),
            ..Default::default()
        };
        let envelope = Wrapper {
            name: ACTION_METHOD.to_owned(),
            data: Bytes::from(action.encode_to_vec()),
            ..Default::default()
        };
        let mut frame = BytesMut::new();
        frame.put_u8(1);
        envelope.encode(&mut frame).unwrap();
        let parsed = decode_live_frame(frame.freeze()).unwrap().unwrap();
        assert_eq!(parsed.name, "ActionDealTile");
        let decoded = ActionDealTile::decode(parsed.data).unwrap();
        assert_eq!(decoded.seat, 2);
        assert_eq!(decoded.tile, "0m");
    }

    #[test]
    fn ignores_rpc_responses_and_rejects_malformed_header() {
        assert!(decode_live_frame(Bytes::from_static(&[3, 0x34, 0x12])).unwrap().is_none());
        assert!(decode_live_frame(Bytes::from_static(&[2, 0x34])).is_err());
        assert!(decode_live_frame(Bytes::new()).is_err());
        assert!(decode_live_frame(Bytes::from_static(&[1, 0xff])).is_err());
    }

    #[test]
    fn malformed_notification_quarantines_without_emitting() {
        let (tx, mut rx) = mpsc::channel(4);
        let mut state = BridgeState::new(1).unwrap();
        state.active = true;
        process_server_binary(Bytes::from_static(&[1, 0xff]), &mut state, &tx);
        assert!(!state.active);
        assert!(rx.try_recv().is_err());
    }

    #[test]
    fn full_output_queue_quarantines_and_requires_a_new_seat_announcement() {
        let (tx, _rx) = mpsc::channel(1);
        tx.try_send("occupied".to_owned()).unwrap();
        let mut state = BridgeState::new(1).unwrap();
        state.announced = true;
        let action = ActionPrototype {
            step: 1,
            name: "ActionNewRound".to_owned(),
            data: Bytes::from_static(include_bytes!("../tests/fixtures/public_live_new_round_xor.bin")),
        };
        let envelope = Wrapper { name: ACTION_METHOD.to_owned(), data: Bytes::from(action.encode_to_vec()) };
        let mut frame = BytesMut::new();
        frame.put_u8(1);
        envelope.encode(&mut frame).unwrap();
        process_server_binary(frame.freeze(), &mut state, &tx);
        assert!(!state.active);
        assert!(!state.announced);
    }

    #[tokio::test]
    async fn relays_unchanged_binary_and_decodes_public_live_action() {
        timeout(Duration::from_secs(10), async {
            let upstream_listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let upstream_addr = upstream_listener.local_addr().unwrap();
            let local_listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let local_addr = local_listener.local_addr().unwrap();

            // The XORed ActionNewRound body is a public captured live body;
            // the surrounding ActionPrototype and Wrapper are synthetic.
            // Do not apply XOR a second time when constructing the frame.
            let make_frame = |step, name: &str, data| {
                let action = ActionPrototype { step, name: name.to_owned(), data };
                let envelope = Wrapper {
                    name: ACTION_METHOD.to_owned(),
                    data: Bytes::from(action.encode_to_vec()),
                };
                let mut encoded = BytesMut::new();
                encoded.put_u8(1);
                envelope.encode(&mut encoded).unwrap();
                encoded.freeze()
            };
            let expected_frame = make_frame(1, "ActionNewRound", Bytes::from_static(include_bytes!("../tests/fixtures/public_live_new_round_xor.bin")));
            // The draw and discard bodies below are generated fixtures; only
            // the opening round's inner payload was captured from real traffic.
            let discard = ActionDiscardTile { seat: 0, tile: "5z".to_owned(), moqie: false, ..Default::default() };
            let discard_frame = make_frame(2, "ActionDiscardTile", live_action_xor(&discard.encode_to_vec()));
            let draw = ActionDealTile { seat: 1, tile: "0p".to_owned(), ..Default::default() };
            let draw_frame = make_frame(3, "ActionDealTile", live_action_xor(&draw.encode_to_vec()));

            let (handshake_tx, handshake_rx) = oneshot::channel();
            let (client_payload_tx, client_payload_rx) = oneshot::channel();
            let outgoing_frame = expected_frame.clone();
            let outgoing_discard = discard_frame.clone();
            let outgoing_draw = draw_frame.clone();
            let upstream_task = tokio::spawn(async move {
                let (socket, _) = upstream_listener.accept().await.unwrap();
                let mut peer = accept_hdr_async(socket, move |request: &Request, response: Response| {
                    let read = |name: header::HeaderName| request.headers().get(name).unwrap().to_str().unwrap().to_owned();
                    let values = [read(header::ORIGIN), read(header::COOKIE), read(header::AUTHORIZATION)];
                    let _ = handshake_tx.send(values);
                    Ok(response)
                }).await.unwrap();
                let received = peer.next().await.unwrap().unwrap();
                client_payload_tx.send(received).unwrap();
                peer.send(Message::Binary(outgoing_frame)).await.unwrap();
                peer.send(Message::Binary(outgoing_discard)).await.unwrap();
                peer.send(Message::Binary(outgoing_draw)).await.unwrap();
                // Wait until the client closes, so the test also exercises the
                // relay's close path instead of dropping the server early.
                let _ = peer.next().await;
            });

            let (events_tx, mut events_rx) = mpsc::channel(16);
            let upstream_url = format!("ws://{upstream_addr}/game-gateway");
            let relay_task = tokio::spawn(async move {
                let (socket, _) = local_listener.accept().await.unwrap();
                relay_connection(socket, &upstream_url, 1, events_tx).await
            });
            let mut client_request = format!("ws://{local_addr}/game-gateway").into_client_request().unwrap();
            client_request.headers_mut().insert(header::ORIGIN, "https://example.invalid".parse().unwrap());
            client_request.headers_mut().insert(header::COOKIE, "test=fake".parse().unwrap());
            client_request.headers_mut().insert(header::AUTHORIZATION, "Bearer fake".parse().unwrap());
            let (mut client, _) = connect_async(client_request).await.unwrap();
            let sent = Bytes::from_static(&[2, 0x34, 0x12, 0x0a, 0x00]);
            client.send(Message::Binary(sent.clone())).await.unwrap();

            assert_eq!(handshake_rx.await.unwrap(), ["https://example.invalid".to_owned(), "test=fake".to_owned(), "Bearer fake".to_owned()]);
            assert_eq!(client_payload_rx.await.unwrap(), Message::Binary(sent));
            assert_eq!(client.next().await.unwrap().unwrap(), Message::Binary(expected_frame));
            assert_eq!(client.next().await.unwrap().unwrap(), Message::Binary(discard_frame));
            assert_eq!(client.next().await.unwrap().unwrap(), Message::Binary(draw_frame));
            let start_game: serde_json::Value = serde_json::from_str(&events_rx.recv().await.unwrap()).unwrap();
            let start_round: serde_json::Value = serde_json::from_str(&events_rx.recv().await.unwrap()).unwrap();
            let dealer_draw: serde_json::Value = serde_json::from_str(&events_rx.recv().await.unwrap()).unwrap();
            assert_eq!(start_game, serde_json::json!({"type":"start_game", "id":1}));
            assert_eq!(start_round["type"], "start_kyoku");
            assert_eq!(start_round["bakaze"], "E");
            assert_eq!(start_round["kyoku"], 1);
            assert_eq!(start_round["oya"], 0);
            assert_eq!(start_round["dora_marker"], "2p");
            assert_eq!(start_round["scores"], serde_json::json!([25000,25000,25000,25000]));
            assert_eq!(start_round["tehais"][1], serde_json::json!(["1m","5m","9m","4p","4p","2s","2s","6s","7s","7s","8s","8s","E"]));
            assert_eq!(dealer_draw, serde_json::json!({"type":"tsumo", "actor":0, "pai":"?"}));
            let discard_event: serde_json::Value = serde_json::from_str(&events_rx.recv().await.unwrap()).unwrap();
            let draw_event: serde_json::Value = serde_json::from_str(&events_rx.recv().await.unwrap()).unwrap();
            assert_eq!(discard_event, serde_json::json!({"type":"dahai", "actor":0, "pai":"P", "tsumogiri":false}));
            assert_eq!(draw_event, serde_json::json!({"type":"tsumo", "actor":1, "pai":"5pr"}));

            client.close(None).await.unwrap();
            relay_task.await.unwrap().unwrap();
            upstream_task.await.unwrap();
        }).await.expect("loopback relay timed out");
    }

    #[tokio::test]
    async fn rejects_client_subprotocol_instead_of_misrepresenting_negotiation() {
        timeout(Duration::from_secs(5), async {
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let addr = listener.local_addr().unwrap();
            let (events_tx, _events_rx) = mpsc::channel(4);
            let relay_task = tokio::spawn(async move {
                let (socket, _) = listener.accept().await.unwrap();
                relay_connection(socket, "ws://127.0.0.1:1", 0, events_tx).await
            });
            let mut request = format!("ws://{addr}/").into_client_request().unwrap();
            request.headers_mut().insert(header::SEC_WEBSOCKET_PROTOCOL, "example.v1".parse().unwrap());
            let error = connect_async(request).await.unwrap_err();
            match error {
                tokio_tungstenite::tungstenite::Error::Http(response) => assert_eq!(response.status(), StatusCode::BAD_REQUEST),
                _ => panic!("unexpected WebSocket handshake error"),
            }
            assert!(relay_task.await.unwrap().is_err());
        }).await.expect("subprotocol rejection timed out");
    }
}
