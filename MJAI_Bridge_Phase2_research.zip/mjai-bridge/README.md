# MJAI bridge — Phase 2 research prototype

This project is a **partial, unverified-at-runtime prototype**, not a complete Mahjong Soul client integration. It provides a local WebSocket relay, a small wire-compatible Protobuf subset, and conversion of selected four-player gameplay notifications into MJAI JSON lines.

## Validation status

- The selected field numbers and types were compared against the Unity-extracted Akagi schema, MahjongCopilot's independently maintained schema, and the older mahjong-helper schema. See [proto/README.md](proto/README.md).
- An independently published, historical live `ActionNewRound` **inner payload** has been XOR-decoded and its hand, scores, and dora fields independently checked against the included schema. The outer WebSocket wrapper used in tests is synthetic. A second fixture contains a plaintext restore payload. Neither is a current live-server end-to-end test.
- Rust unit tests include tile mapping, malformed input, desynchronization/recovery, protobuf framing, and a loopback WebSocket test. **The authoring environment has no Rust compiler or Cargo, so these tests and `cargo build` have not been run.** No promise of a warning-free build or working live client is made.
- No verified public repository exposing the requested separate `Action*.proto` files was found. The known sources are monolithic and also contain login/lobby definitions. The script deliberately does not download those monolithic files. Its default sync therefore reports the limitation; its local `--check` works. See [proto/README.md](proto/README.md) for its optional pinned split-source interface.

## Build and local checks

Install a current stable Rust toolchain and use a machine that can access your Cargo registry the first time. The build uses `protoc-bin-vendored`; a separately installed `protoc` is not required.

```sh
python3 scripts/sync_proto.py --check
cargo build
cargo test
```

The first command verifies the included subset against the script's expected local declarations; it does not independently contact a server or establish that the deployed game protocol has not changed. The runtime is Rust-only. Python is used solely by the optional schema utility.

## Configuration and operation

```sh
cargo run --release -- --upstream 'wss://YOUR_GAME_GATEWAY_URL' --seat 1
```

`--upstream` must be the actual game WebSocket URL for the connection you choose, and `--seat` must be your actual absolute seat ID from 0 to 3. They cannot be inferred from the gameplay-only subset. The listener defaults to `127.0.0.1:12121`; `--listen` can select another loopback address. Output events are JSON lines on stdout; diagnostic messages use stderr.

**The client must be configured to connect to `ws://127.0.0.1:12121`.** Merely starting the bridge does not redirect an existing `wss://` connection, intercept browser traffic, obtain the gateway URL, or arrange client authentication. This is a local WebSocket endpoint, not an HTTP CONNECT/TLS-interception proxy. Only one explicitly selected game socket is handled at a time; an independently open lobby socket is outside its scope. Consequently `cargo run` followed by opening the unmodified official game is not, by itself, an end-to-end setup.

The relay forwards binary and text message payloads unchanged. It copies Origin, Cookie, and Authorization headers when the local client sends them, without logging their values; browsers may not send an upstream site's cookies to a loopback address. The two WebSocket handshakes are independent: the bridge rejects clients requesting a subprotocol, terminates ping/pong locally, and does not implement WebSocket compression or arbitrary header forwarding. These restrictions can prevent a real client from connecting even if its URL is redirected.

## Wire path

The WebSocket message body begins with a kind byte: `1` for notifications, `2` for requests, or `3` for responses; request and response frames then include a two-byte little-endian request ID. This is not a `[u16 length][u16 type]` header. Only notifications named `.lq.ActionPrototype` are decoded here. Its nested action `data` is XOR-decoded before the appropriate gameplay message is decoded. Restore/sync payloads are not handled by this notification decoder and must not be blindly XORed.

The `.proto` file defines only the wrapper and fields used by this prototype. Protobuf unknown fields are discarded by the decoder; the original WebSocket message is forwarded untouched. `Bytes` allows the wrapper slices to share storage, but XOR decoding allocates a new output buffer. This is not end-to-end zero-copy.

## MJAI scope and synchronization

Supported mappings: `ActionNewRound` → `start_game`/`start_kyoku` and an unknown dealer draw; `ActionDealTile` → `tsumo`; and `ActionDiscardTile` → `dahai` with `tsumogiri = moqie`. Mahjong Soul's wire tiles are strings: `0m`, `0p`, and `0s` represent red fives; `1z`–`7z` are honors. A separate 34-index helper exists for callers that already have integer tile IDs.

Only four-player rounds with a known 13-tile local starting hand are accepted. Opponent starting tiles and hidden draws are represented as `?`. If the local player is the dealer and receives 14 initial tiles, the payload does not establish which tile was the initial physical draw; this prototype refuses to fabricate one and waits for a supported future round. It also quarantines the stream after malformed or unsupported state-changing actions, action-step gaps, changed dora, riichi, or output loss, and resumes only at a valid new round. The original traffic continues to be relayed. Melds, round-end details, three-player games, and reconnect/restore are not converted.

Do not treat this subset as a complete rules engine or as support for all special event modes. Unknown future Protobuf fields can still change meaning without a decoding error; verify the schema against the target client version and extend the converter before relying on it.

## Phase 1 compatibility

The emitted basic JSON uses the fields and 13-tile starting-hand structure accepted by Phase 1. Phase 1 itself reads stdin to EOF, emits one mock/model result, and exits; **piping an indefinitely running bridge into the existing Phase 1 executable does not produce real-time inference**. Its toy ONNX feature/action contract is also not Mortal's. A streaming engine loop and complete rules/action representation are separate work.
