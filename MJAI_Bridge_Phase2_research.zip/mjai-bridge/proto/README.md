# Gameplay protocol subset

`gameplay.proto` is a deliberately partial `package lq` schema. It retains the
wire types and tag numbers needed by the bridge, not the complete message
definitions. Unknown protobuf fields are intentionally ignored. In particular,
it does not define any login or lobby messages, calls, or reconnect snapshots.

The selected fields were checked against:

- [Akagi's Unity-client-derived protocol documentation](https://protodoc.io/shinkuan/Akagi/lq), including `Wrapper`, `ActionPrototype`, `ActionNewRound`, `ActionDealTile`, and `ActionDiscardTile`.
- [MahjongCopilot's protocol documentation](https://protodoc.io/latorc/MahjongCopilot/lq), an independently maintained schema.
- [The older mahjong-helper schema](https://github.com/EndlessCheng/mahjong-helper/blob/master/platform/majsoul/proto/lq/liqi.proto).

These sources publish monolithic schemas; no actual split Action*.proto source
was found. `python3 scripts/sync_proto.py --check` checks the included subset
without network access. Running the script without options reports the absence
of a verified split source and exits unsuccessfully rather than claiming a sync.
An optional `--base-url` is available only if a suitable split source is later
identified, and demands a full commit hash. It requests only the four named
Action*.proto files and validates all selected types and tags before writing.
The optional remote path has been tested with mocked downloads only; no known
real remote source has been verified.

A public encrypted `ActionNewRound` payload reported on 2023-02-07 at
[majsoul_wrapper issue #18](https://github.com/747929791/majsoul_wrapper/issues/18)
provides an independent historical sample. Applying the known live-action XOR
yields a hand in field 4, packed scores in field 6, and a dora in field 14:
`[1m,5m,9m,4p,4p,2s,2s,6s,7s,7s,8s,8s,1z]`, `[25000,25000,25000,25000]`,
`[2p]`. This is only the inner payload, not a captured full WebSocket frame,
and does not prove compatibility with the currently deployed client.
