# Fixture provenance

- `public_live_new_round_xor.bin` is the Base64-decoded encrypted **inner** `ActionNewRound` payload reported in [majsoul_wrapper issue #18](https://github.com/747929791/majsoul_wrapper/issues/18). It is a historical sample. Any `Wrapper` / `ActionPrototype` around it in the tests is synthetic. Expected decoded tiles are `1m 5m 9m 4p 4p 2s 2s 6s 7s 7s 8s 8s 1z`, scores are four 25000s, and the dora is `2p`. SHA-256: `5bc38255a9b23ad99a197e293d253452470a3c60a5fc87bd66e0a802498d8ac3`.
- `akagi_restore_new_round.bin` is the decoded `RESTORE_NEW_ROUND_B64` fixture from [Akagi's Mahjong Soul parser tests](https://github.com/shinkuan/Akagi/blob/v3/src/bridge/majsoul/parser.rs). It is a plaintext restore payload; do **not** apply the live notification XOR to it. Its tiles are `4p 1m 3p 4z 7z 6z 0p 3s 0m 4s 1s 9s 2z`, scores are four 25000s, and the dora is `1z`. SHA-256: `8a08a2eeda1a7c788c4c92d10b6ff82e512b84a7f20185e228ce6b709888762f`.

These small test inputs do not prove compatibility with the current game server or a complete MJAI state machine.
