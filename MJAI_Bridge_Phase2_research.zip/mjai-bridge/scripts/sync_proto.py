#!/usr/bin/env python3
"""Verify a user-supplied pinned split-proto source and refresh the tiny subset.

No known public repo providing the expected split Action*.proto files has been
verified. Without --base-url, fail explicitly rather than fetching a monolithic
schema containing login/lobby messages or claiming an invented source works.

If a real split source becomes available, pass its *raw.githubusercontent.com*
folder URL pinned to a full 40-hex commit SHA. Only the four Action*.proto files
listed below will be fetched; imports and all login/lobby files are never fetched.
The generator validates the wire types and tags before writing gameplay.proto.
It detects schema drift but does not automatically accommodate incompatible tags.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

PROJECT = Path(__file__).resolve().parents[1]
DESTINATION = PROJECT / "proto" / "gameplay.proto"
MAX_FILE_BYTES = 256 * 1024

# (proto declaration, field name, field number). All tags have been checked
# against the three public liqi schemas linked in the generated file.
FIELDS = {
    "Wrapper": [
        ("string", "name", 1), ("bytes", "data", 2),
    ],
    "ActionPrototype": [
        ("uint32", "step", 1), ("string", "name", 2), ("bytes", "data", 3),
    ],
    "ActionNewRound": [
        ("uint32", "chang", 1), ("uint32", "ju", 2), ("uint32", "ben", 3),
        ("repeated string", "tiles", 4), ("string", "dora", 5),
        ("repeated int32", "scores", 6), ("uint32", "liqibang", 8),
        ("repeated string", "doras", 14),
        ("repeated NewRoundOpenedTiles", "opens", 15), ("MuyuInfo", "muyu", 16),
        ("uint32", "field_spell", 18), ("YongchangInfo", "yongchang", 20),
    ],
    "NewRoundOpenedTiles": [
        ("uint32", "seat", 1), ("repeated string", "tiles", 2),
        ("repeated uint32", "count", 3),
    ],
    # Presence-only nested types: their fields are intentionally omitted.
    # Unlike these types, NewRoundOpenedTiles retains tiles/count so callers
    # can distinguish an empty ordinary entry from special opening tiles.
    "LiQiSuccess": [],
    "MuyuInfo": [],
    "YongchangInfo": [],
    "ActionDealTile": [
        ("uint32", "seat", 1), ("string", "tile", 2),
        ("uint32", "left_tile_count", 3), ("LiQiSuccess", "liqi", 5),
        ("repeated string", "doras", 6), ("uint32", "tile_state", 9),
        ("MuyuInfo", "muyu", 10),
    ],
    "ActionDiscardTile": [
        ("uint32", "seat", 1), ("string", "tile", 2), ("bool", "is_liqi", 3),
        ("bool", "moqie", 5), ("repeated string", "doras", 8),
        ("bool", "is_wliqi", 9), ("uint32", "tile_state", 10),
        ("MuyuInfo", "muyu", 11), ("bool", "revealed", 12),
        ("YongchangInfo", "yongchang", 25),
    ],
}
ALLOWLIST = ("ActionPrototype", "ActionNewRound", "ActionDealTile", "ActionDiscardTile")
HEADER = '''// A deliberately partial wire-compatible gameplay schema, NOT the full protocol.
// Unknown protobuf fields are skipped by prost; names/types/tags here matter.
// Cross-checked against these public, independently maintained schemas:
// https://protodoc.io/shinkuan/Akagi/lq (recent Unity-client-derived schema)
// https://protodoc.io/latorc/MahjongCopilot/lq
// https://github.com/EndlessCheng/mahjong-helper/blob/master/platform/majsoul/proto/lq/liqi.proto
// Wrapper is local because only Action*.proto and Res*.proto may be downloaded.
syntax = "proto3";
package lq;

'''


def render_subset() -> str:
    blocks = []
    for name, fields in FIELDS.items():
        if not fields:
            blocks.append(f"message {name} {{}}\n")
            continue
        body = "\n".join(f"  {kind} {field} = {number};" for kind, field, number in fields)
        blocks.append(f"message {name} {{\n{body}\n}}\n")
    return HEADER + "\n".join(blocks)


def validate_base_url(url: str) -> str:
    """Accept only a raw GitHub folder containing a fully pinned commit."""
    parsed = urlsplit(url)
    pieces = parsed.path.strip("/").split("/")
    if (
        parsed.scheme != "https"
        or parsed.netloc != "raw.githubusercontent.com"
        or parsed.query
        or parsed.fragment
        or len(pieces) < 4
        or not re.fullmatch(r"[0-9a-fA-F]{40}", pieces[2])
        or any(not re.fullmatch(r"[A-Za-z0-9_.-]+", p) or p in (".", "..") for p in pieces)
        or any(re.search(r"login|lobby", p, re.IGNORECASE) for p in pieces[3:])
    ):
        raise ValueError("base URL must be https://raw.githubusercontent.com/OWNER/REPO/FULL_40_HEX_COMMIT/DIRECTORY")
    return url.rstrip("/")


class NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def download(base: str, name: str) -> str:
    if name not in ALLOWLIST:
        raise ValueError("attempt to fetch a message outside the gameplay allowlist")
    url = f"{base}/{name}.proto"
    request = Request(url, headers={"Accept": "text/plain", "User-Agent": "mjai-bridge-schema-check/1"})
    with build_opener(NoRedirects()).open(request, timeout=20) as response:
        data = response.read(MAX_FILE_BYTES + 1)
    if len(data) > MAX_FILE_BYTES:
        raise ValueError(f"{name}.proto is too large")
    return data.decode("utf-8")


def message_body(source: str, name: str) -> str:
    # Drop comments before counting braces. A source using unusual syntax that
    # this checker cannot understand fails validation; it is never auto-trusted.
    clean = re.sub(r"/\*.*?\*/|//[^\n]*", "", source, flags=re.DOTALL)
    if not re.search(r"\bpackage\s+lq\s*;", clean):
        raise ValueError(f"{name}.proto is not in package lq")
    if re.search(r"\bmessage\s+\w*(?:login|lobby)\w*\b", clean, re.IGNORECASE):
        raise ValueError(f"{name}.proto unexpectedly contains a login/lobby message")
    matches = list(re.finditer(r"\bmessage\s+" + re.escape(name) + r"\s*\{", clean))
    if len(matches) != 1:
        raise ValueError(f"{name}.proto must contain exactly one {name} definition")
    start = matches[0].end()
    depth = 1
    for pos in range(start, len(clean)):
        if clean[pos] == "{":
            depth += 1
        elif clean[pos] == "}":
            depth -= 1
            if depth == 0:
                return clean[start:pos]
    raise ValueError(f"{name}.proto contains unbalanced braces")


def validate_source(source: str, name: str) -> None:
    body = message_body(source, name)
    for kind, field, number in FIELDS[name]:
        pieces = kind.split()
        # Normalize arbitrary whitespace and allow the proto3 optional keyword
        # on otherwise singular fields (the wire encoding is identical).
        prefix = r"\s+".join(map(re.escape, pieces))
        if len(pieces) == 1:
            prefix = r"(?:optional\s+)?" + prefix
        pattern = (
            r"(?<![A-Za-z0-9_])" + prefix + r"\s+" + re.escape(field)
            + r"\s*=\s*" + str(number) + r"\s*(?:\[[^;]*\])?\s*;"
        )
        if not re.search(pattern, body):
            raise ValueError(f"{name}: required field {kind} {field} = {number} missing or changed")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", help="pinned raw GitHub directory containing split Action*.proto files")
    parser.add_argument("--check", "--check-local", action="store_true", help="verify the vendored schema is unchanged, without network")
    args = parser.parse_args(argv)
    expected = render_subset()
    if args.check:
        if not DESTINATION.is_file() or DESTINATION.read_text(encoding="utf-8") != expected:
            print("vendored gameplay schema differs from the expected subset", file=sys.stderr)
            return 1
        print(f"verified local gameplay subset: {DESTINATION}")
        return 0
    if not args.base_url:
        print("No verified split Action*.proto upstream is known; no network request was made.", file=sys.stderr)
        print("The checked-in partial gameplay schema remains available for cargo build.", file=sys.stderr)
        print("If you have a verified split source, provide a 40-hex-commit-pinned --base-url.", file=sys.stderr)
        return 2
    try:
        base = validate_base_url(args.base_url)
        for name in ALLOWLIST:
            validate_source(download(base, name), name)
        DESTINATION.parent.mkdir(parents=True, exist_ok=True)
        pending = DESTINATION.with_suffix(".proto.tmp")
        pending.write_text(expected, encoding="utf-8", newline="\n")
        pending.replace(DESTINATION)
    except (ValueError, UnicodeError, OSError, HTTPError, URLError) as error:
        print(f"schema sync failed; existing schema was not replaced: {error}", file=sys.stderr)
        return 1
    print(f"verified all {len(ALLOWLIST)} allowlisted files; wrote {DESTINATION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
